
## About this project

Abyssinica SIL is based on Ethiopic calligraphic traditions. The Ethiopic script is used for writing many of the languages of Ethiopia and Eritrea. This project is intended to provide a free and open font for all current languages and writing systems that use the Ethiopic script. It supports the complete range of Unicode characters for Ethiopic.  

For more information on the visual characteristics of the font see [Design](design).


## Future plans

This font is actively maintained and improved, and recent changes to its development process will enable more frequent releases.

The highest priorities for future additions and enhancements are mainly driven by:

- New additions to [The Unicode Standard](https://unicode.org/)
- Requests from language communities using the fonts
- Needs of the linguistic and academic community

Please send us your requests using the [form on the font website](https://software.sil.org/abyssinica/about/contact/). If you are interested in helping us make the font better see the [Developer](developer) page.

## Announcement list

If you wish to receive announcements about updates to any of our SIL fonts, please subscribe to our [SIL Font News Announcement List](https://groups.google.com/a/groups.sil.org/forum/#!forum/sil-font-news). This is an announcement-only list with messages approximately once a month. It does not allow any discussion.

You can subscribe using either of the two following options.

- If you use a Google profile and join the group, you will be able to access the group and control your subscription and notification options with a web browser. Make sure you are logged in to your Google profile and go to the [SIL Font News Google Group](https://groups.google.com/a/groups.sil.org/forum/#!forum/sil-font-news). Click on **Join group**.

- If you would rather not use a Google profile, you can subscribe any email address by sending a message to [sil-font-news+subscribe@groups.sil.org](mailto:sil-font-news+subscribe@groups.sil.org) and following the instructions you get in the confirmation message.

Our font announcements are also available through Twitter [@silfonts](http://twitter.com/silfonts).

## Supporting the project

This font is  provided at no cost, however it is expensive to produce and maintain. Please consider donating to SIL’s font development efforts to support future development. Go to [SIL’s Give Direct page](https://donate.givedirect.org/?cid=13536&n=206909) and designate your gift for _Scripts & Fonts_. **Thank you!** 

## About SIL International

[SIL International](http://www.sil.org/) is a global, faith-based nonprofit that works with local communities around the world to develop language solutions that expand possibilities for a better life. 

We are involved in approximately 1,350 active language projects in 104 countries. These projects impact more than 1.1 billion people within 1,600 local communities. SIL’s work brings together more than 4,300 staff from 89 countries who work alongside thousands more local partners and community volunteers worldwide. Our services are available without regard to religious belief, political ideology, gender, race or ethnic background.

Our Vision: We long to see people flourishing in community using the languages they value most. 

Our Mission: Inspired by God’s love, we advocate, build capacity, and work with local communities to apply language expertise that advances meaningful development, education, and engagement with Scripture.

[SIL Language Technology](https://software.sil.org/) supports these activities by developing [software](https://software.sil.org/products/), [fonts](https://software.sil.org/fonts/), and [keyboard technologies](https://keyman.com/).
